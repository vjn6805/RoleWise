// src/background.ts
chrome.runtime.onInstalled.addListener(() => {
  void chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
});
chrome.action.onClicked.addListener((tab) => {
  if (tab.id === void 0) return;
  const fallback = () => chrome.tabs.create({ url: chrome.runtime.getURL(`panel.html?sourceTab=${tab.id}`) });
  if (chrome.sidePanel?.open) {
    void chrome.sidePanel.open({ tabId: tab.id }).catch(() => fallback());
  } else void fallback();
});
